from django.contrib import admin
from .models import *

# Register your models here.

@admin.register(Alert)
class Alert(admin.ModelAdmin):
    list_display = ('symbol','stratergy','start_time','run_till')

@admin.register(Executed_Stratergy)
class Executed_Stratergy(admin.ModelAdmin):
    list_display = ('remark',)