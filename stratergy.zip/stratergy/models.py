from django.db import models
from django.contrib.auth import get_user_model
import threading
from stratergy.stratergies.low_high import manual_input_strat

User = get_user_model()

# Create your models here.
stratergy_option = [
        ('Manual Input', 'Manual Input'),
    ]

class Alert(models.Model):
    id=models.AutoField(primary_key=True)
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    datetime = models.DateTimeField(auto_now_add=True,null=True)
    url = models.CharField(max_length=150)
    upstox_access_token = models.CharField(max_length=5000,default="")
    stratergy = models.CharField(choices=stratergy_option,max_length=50,default="")
    symbol = models.CharField(max_length=50,default="Same as present in Onstock")
    buy_syntax = models.TextField()
    sell_syntax = models.TextField()
    high = models.PositiveIntegerField(default=0)
    low = models.PositiveIntegerField(default=0)
    start_time = models.TimeField()
    run_till = models.PositiveIntegerField(default=30)
    class Meta:
        verbose_name = "Alert"
        verbose_name_plural = "Alerts"
    def save(self, *args, **kwargs):
        f = open("token.txt", "w")
        f.write(self.access_token)
        f.close()
        thread = threading.Thread(target=manual_input_strat,args = (self.symbol,self.high,self.low,self.start_time,self.run_till,self.buy_syntax,self.sell_syntax,self.url))
        thread.start()
        super().save(*args, **kwargs)
    def __str__(self):
      return self.id
    

class Executed_Stratergy(models.Model):
    id=models.AutoField(primary_key=True)
    datetime = models.DateTimeField(auto_now_add=True,null=True)
    remark = models.CharField(max_length=100)
    syntax_used = models.TextField()
    response = models.TextField()

    class Meta:
        verbose_name = "Executed Orders"
        verbose_name_plural = "Order"

    def __str__(self):
        return self.id