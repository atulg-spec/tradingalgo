import pandas as pd

def get_instrument(exchange_token):
    if str(exchange_token).strip() == '':
        return None
    exchange_token = float(exchange_token)
    df = pd.read_csv('complete.csv')
    instrument = df[df['exchange_token'] == exchange_token]
    if instrument.empty:
        return None
    else:
        return instrument.iloc[0]['instrument_key']
    

# Example usage:
token = '425299'
token = float(token)
result = get_instrument(token)
print('-=-=-=-=-=-Instrument-=-=-===-=--=--')
print(result)

# df = pd.read_csv('complete.csv')
# # for x in df['exchange_token']:
# #     print(x)
# print(df['exchange_token'])
# if 'USDINR2421680.1CE' in df['exchange_token']:
#     print('Hello World')