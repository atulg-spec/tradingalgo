import json
from stratergy.symbols.getsymbols import exc_symbols
from stratergy.symbols.instruments import get_instrument
import upstox_client


# SYMBOL LIST
symbollist = {}
symboldata = exc_symbols()
for i in symboldata:
    temp = {'symbol':i,'segment':symboldata[i]['exchange'],'token':symboldata[i]['token']}
    symbollist[i] = temp
# END SYMBOL LIST

def get_market_data(upstox_symbol_list):
    try:
        # access_token = asyncio(sync_to_async(Upstox.objects.first().access_token))
        f = open("token.txt", "r")
        access_token = f.read()
        f.close()
        # access_token = 'eyJ0eXAiOiJKV1QiLCJrZXlfaWQiOiJza192MS4wIiwiYWxnIjoiSFMyNTYifQ.eyJzdWIiOiIyOEFaNDUiLCJqdGkiOiI2NTg2OTRhZTJmYjY1ODEwYThmNzg1YWIiLCJpc011bHRpQ2xpZW50IjpmYWxzZSwiaXNBY3RpdmUiOnRydWUsInNjb3BlIjpbImludGVyYWN0aXZlIiwiaGlzdG9yaWNhbCJdLCJpYXQiOjE3MDMzMTg3MDIsImlzcyI6InVkYXBpLWdhdGV3YXktc2VydmljZSIsImV4cCI6MTcwMzM2ODgwMH0.fpqN0dk6aLG1tCBJcrJFyT0wl_Lj1t-7uzTdGXTeHz0'
        configuration = upstox_client.Configuration()
        configuration.access_token = access_token
        api_instance = upstox_client.MarketQuoteApi(upstox_client.ApiClient(configuration))
        api_version = 'v-2'
        api_response = api_instance.get_market_quote_ohlc(upstox_symbol_list, '1d', api_version)
        return api_response.to_dict()
    except Exception as e:
        return None
    

def get_price(symbol,c=1):
    data = symbollist.get(symbol)
    instrument = get_instrument(data['token'])
    try:
        market_data = get_market_data(instrument)
        symbol_data = market_data['data'][f"{data['segment']}:{symbol}"]
        return symbol_data.get('last_price', 0)
    except Exception as e:
        co = c+1
        if co == 2:
            return 0.0
        return get_price(symbol,c=co)