from dhanhq import dhanhq
import datetime
import upstox_client
import time
from stratergy.symbols.details import get_price, symbollist, get_market_data, get_instrument

client_id = "1100617939"
access_token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJkaGFuIiwicGFydG5lcklkIjoiIiwiZXhwIjoxNzAzOTA5NDk0LCJ0b2tlbkNvbnN1bWVyVHlwZSI6IlNFTEYiLCJ3ZWJob29rVXJsIjoiIiwiZGhhbkNsaWVudElkIjoiMTEwMDYxNzkzOSJ9.qJkrDil7DJeAizbFWs3LGXdNqHIWKQMVisrrCOeJAlbcUvahmArsFEimIgrXkQu50nKPOgDkn5d0ToPBd2x5qg"

def manual_input_strat(symbol,high,low,start_time,run_till,buy_syntax,sell_syntax,url):
    from stratergy.models import Executed_Stratergy
    last_volume
    dhan = dhanhq(client_id,access_token)
    last_volume = 50000000000
    high = 270
    low = 252
    start_time = time.time()
    end_time = start_time + (60 * run_till)
    while datetime.datetime.now().time() < start_time :
        time.sleep(60)
    data = symbollist.get(symbol)
    token = data['token']
    while time.time() < end_time:
        a = dhan.intraday_daily_minute_charts(
            security_id='425345',
            exchange_segment='MCX_COMM',
            instrument_type='OPTFUT'
        )
        print('LTP Price')
        ltp = int(get_price('symbol'))
        print(ltp)
        current_volume = int(a['data']['volume'][-1])
        print('high \t low \t open \t close \t volume')
        print(f"{a['data']['high'][-1]} \t {a['data']['low'][-1]} \t {a['data']['open'][-1]} \t {a['data']['close'][-1]} \t {a['data']['volume'][-1]}")
        if (ltp > high and current_volume > last_volume):
            # PLACE BUY ORDER
            data = symbollist.get(symbol)
            instrument = get_instrument(data['token'])
            response = get_market_data(instrument)
            Executed_Stratergy.objects.create(remark='Buy Position Created',syntax_used=buy_syntax,respomse=response)
            break # Break for while loop
        elif (ltp < low and current_volume > last_volume):
            # PLACE SELL ORDER
            Executed_Stratergy.objects.create(remark='Sell Position Created',syntax_used=sell_syntax,respomse=response)
            break # Break for while loop
        last_volume = int(current_volume)
        time.sleep(1)  
        print('-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-==-=-=-=-=-')
    return None


